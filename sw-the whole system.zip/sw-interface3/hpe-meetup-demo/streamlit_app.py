import streamlit as st
import pandas as pd
import software_pro  # Import your model from the .py file

# Set Streamlit page configuration
st.set_page_config(layout="wide")
st.title("🦠: Malware Detection System")

# Let user upload a CSV file
uploaded_file = st.file_uploader("Upload CSV file", type=["csv"])

if uploaded_file is not None:
    st.write("🎉 File uploaded successfully!")
    df = pd.read_csv(uploaded_file)

    # Define numerical columns for standardization
    numerical_cols = ['pslist_avg_threads', 'svcscan_nservices', 'handles_nkey',
                      'svcscan_shared_process_services', 'ldrmodules_not_in_init',
                      'svcscan_process_services', 'handles_nsemaphore',
                      'handles_ntimer', 'ldrmodules_not_in_mem',
                      'ldrmodules_not_in_load', 'handles_nsection',
                      'dlllist_ndlls', 'handles_nthread',
                      'dlllist_avg_dlls_per_proc', 'handles_nmutant',
                      'handles_nevent', 'SubType']

    if 'Label' in df.columns:
        df.drop('Label', axis=1, inplace=True)  # Drop label column if exists

    # Make predictions using the loaded model
    predictions = software_pro.model.predict(df)[0]  # Assuming you have a predict function in software_pro.py

    
    # Display the predictions
    st.write("## Model Prediction Results")

    # if 0 b , 1 m
    if (predictions == 1):
       st.write("mailicious")
    
    if(predictions == 0):
     st.write("benign")

    # Display the predictions
    # st.write("## Model Prediction Results")
    # st.write(predictions)
else:
    st.warning("👈 Please upload a CSV file...")
